package com.hugosmp.autosell;

import net.minecraft.class_1268;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_465;
import net.minecraft.class_7923;

public class AutoSellManager {
    public enum State {
        IDLE,
        WAITING_TIMER,
        OPENING_CHEST,
        WAITING_FOR_CHEST_SCREEN,
        LOOTING_CHEST,
        CLOSING_CHEST,
        WAITING_FOR_INVENTORY_SYNC,
        WAITING_BEFORE_COMMAND,
        SENDING_SELL_COMMAND,
        WAITING_FOR_ORDER_SCREEN,
        WAITING_FOR_ORDER_DELIVERY_SCREEN,
        WAITING_FOR_ORDER_CONFIRMATION,
        WAITING_FOR_SELL_SCREEN,
        FILLING_SELL_GUI,
        CONFIRMING_SELL,
        FINISHING_CYCLE
    }

    private static final AutoSellManager INSTANCE = new AutoSellManager();
    public static AutoSellManager getInstance() {
        return INSTANCE;
    }

    private final AutoSellConfig config = AutoSellConfig.load();
    private boolean active = false;
    private class_2338 targetChestPos;

    {
        // Beim Instanziieren geladene Position aus Config übernehmen
        targetChestPos = config.getChestPos();
    }

    private State state = State.IDLE;
    private int stateTicks = 0;
    private int remainingCooldownTicks = 0;
    private int currentSlotIndex = 0;
    private int fillPlayerSlotIndex = 0;
    private int fillPass = 0;
    private String orderedItemId;

    private AutoSellManager() {}

    public AutoSellConfig getConfig() {
        return config;
    }

    /** Switches between selling and ordering the first item taken from the chest. */
    public boolean toggleCommandMode() {
        config.orderMode = !config.orderMode;
        config.save();
        return config.orderMode;
    }

    public boolean isActive() {
        return active;
    }

    public class_2338 getTargetChestPos() {
        return targetChestPos;
    }

    public State getState() {
        return state;
    }

    public int getRemainingCooldownTicks() {
        return remainingCooldownTicks;
    }

    public void toggle() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        if (active) {
            stop();
            actionBar(mc, "§6[HugoAutoSell] §c✖ Makro DEAKTIVIERT!");
            return;
        }

        // Versuche 1: Kiste anvisiert?
        class_239 hit = mc.field_1765;
        if (hit != null && hit.method_17783() == class_239.class_240.field_1332) {
            class_3965 blockHit = (class_3965) hit;
            class_2338 pos = blockHit.method_17777();
            if (!isStorageBlock(mc, pos)) {
                actionBar(mc, "§6[HugoAutoSell] §cDer Block ist keine Kiste/Truhe! §7Siehe /autosell status");
                return;
            }
            this.targetChestPos = pos;
            config.setChestPos(pos);
            start();
            actionBar(mc, "§6[HugoAutoSell] §a✔ Makro AKTIVIERT! §7Zielkiste: §e"
                    + pos.method_10263() + ", " + pos.method_10264() + ", " + pos.method_10260());
            chat(mc, "§6[HugoAutoSell] §7Intervall: §e" + config.intervalSeconds
                    + "s §7| Starte ersten Verkauf...");
            return;
        }

        // Versuche 2: Zuvor gespeicherte Kiste vorhanden?
        if (this.targetChestPos != null) {
            start();
            actionBar(mc, "§6[HugoAutoSell] §a✔ AKTIVIERT! §7(angepasste Position: §e"
                    + targetChestPos.method_10263() + ", " + targetChestPos.method_10264() + ", " + targetChestPos.method_10260() + "§a)");
            chat(mc, "§6[HugoAutoSell] §7Intervall: §e" + config.intervalSeconds + "s §7| Starte ersten Verkauf...");
            return;
        }

        // Weder noch: Fehler
        actionBar(mc, "§6[HugoAutoSell] §cBitte schaue eine Kiste/Truhe an und drücke [K] erneut!");
        chat(mc, "§6[HugoAutoSell] §7Oder nutze §e/autosell status§7 um die aktuelle Lage zu sehen.");
    }

    public void start() {
        this.active = true;
        this.remainingCooldownTicks = 0;
        this.state = State.OPENING_CHEST;
        this.stateTicks = 0;
        this.fillPlayerSlotIndex = 0;
        this.fillPass = 0;
        this.orderedItemId = null;
    }

    public void stop() {
        this.active = false;
        this.state = State.IDLE;
        this.stateTicks = 0;
        this.remainingCooldownTicks = 0;
        this.fillPlayerSlotIndex = 0;
        this.fillPass = 0;
        this.orderedItemId = null;
    }

    public void onTick(class_310 mc) {
        if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
        }

        if (active) {
            renderActionBar(mc);
            stateTicks++;

            switch (state) {
                case WAITING_TIMER:
                    if (remainingCooldownTicks > 0) {
                        if (remainingCooldownTicks == 1200) {
                            chat(mc, "§6[HugoAutoSell] §e⏳ Nächster Verkauf in 1 Minute...");
                        } else if (remainingCooldownTicks == 200) {
                            chat(mc, "§6[HugoAutoSell] §e⏳ Nächster Verkauf in 10 Sekunden...");
                        }
                        remainingCooldownTicks--;
                    } else {
                        chat(mc, "§6[HugoAutoSell] §b🔄 Timer abgelaufen: Öffne Kiste und verkaufe...");
                        state = State.OPENING_CHEST;
                        stateTicks = 0;
                    }
                    break;

                case OPENING_CHEST:
                    if (targetChestPos == null) {
                        stop();
                        chat(mc, "§c[AutoSell] Keine Kiste ausgewählt! §7Siehe /autosell status");
                        return;
                    }

                    double distSq = mc.field_1724.method_24515().method_10262(targetChestPos);
                    if (distSq > 36.0) {
                        chat(mc, "§c[AutoSell] §7Kiste zu weit entfernt (max. 6 Blöcke)! Makro gestoppt.");
                        stop();
                        return;
                    }

                    if (!isStorageBlock(mc, targetChestPos)) {
                        chat(mc, "§c[AutoSell] §7Gespeicherte Position ist keine Kiste mehr. Makro gestoppt.");
                        config.setChestPos(null);
                        targetChestPos = null;
                        stop();
                        return;
                    }

                    class_3965 hitResult = new class_3965(
                            class_243.method_24953(targetChestPos),
                            class_2350.field_11036,
                            targetChestPos,
                            false
                    );
                    mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hitResult);
                    mc.field_1724.method_6104(class_1268.field_5808);

                    state = State.WAITING_FOR_CHEST_SCREEN;
                    stateTicks = 0;
                    break;

                case WAITING_FOR_CHEST_SCREEN:
                    if (mc.field_1755 instanceof class_465<?>) {
                        state = State.LOOTING_CHEST;
                        stateTicks = 0;
                        currentSlotIndex = 0;
                    } else if (stateTicks > 40) {
                        state = State.OPENING_CHEST;
                        stateTicks = 0;
                    }
                    break;

                case LOOTING_CHEST:
                    if (!(mc.field_1755 instanceof class_465<?> handledScreen)) {
                        state = State.OPENING_CHEST;
                        stateTicks = 0;
                        return;
                    }

                    class_1703 handler = handledScreen.method_17577();
                    int containerSlots = getTopContainerSlotCount(handler);

                    if (stateTicks % Math.max(1, config.clickDelayTicks) == 0) {
                        boolean itemMoved = false;
                        while (currentSlotIndex < containerSlots) {
                            class_1735 slot = handler.method_7611(currentSlotIndex);
                            if (slot != null && slot.method_7681() && !slot.method_7677().method_7960()) {
                                if (config.orderMode && orderedItemId == null) {
                                    orderedItemId = class_7923.field_41178.method_10221(slot.method_7677().method_7909()).method_12832();
                                }
                                mc.field_1761.method_2906(handler.field_7763, currentSlotIndex, 0, class_1713.field_7794, mc.field_1724);
                                currentSlotIndex++;
                                itemMoved = true;
                                break;
                            }
                            currentSlotIndex++;
                        }

                        if (!itemMoved && currentSlotIndex >= containerSlots) {
                            state = State.CLOSING_CHEST;
                            stateTicks = 0;
                        }
                    }
                    break;

                case CLOSING_CHEST:
                    if (mc.field_1724 != null) {
                        mc.field_1724.method_7346();
                    }
                    mc.method_1507(null);
                    state = State.WAITING_FOR_INVENTORY_SYNC;
                    stateTicks = 0;
                    break;

                case WAITING_FOR_INVENTORY_SYNC:
                    if (stateTicks >= 10) {
                        state = State.WAITING_BEFORE_COMMAND;
                        stateTicks = 0;
                    }
                    break;

                case WAITING_BEFORE_COMMAND:
                    if (stateTicks >= 6) {
                        state = State.SENDING_SELL_COMMAND;
                        stateTicks = 0;
                    }
                    break;

                case SENDING_SELL_COMMAND:
                    if (mc.field_1724 != null && mc.field_1724.field_3944 != null) {
                        if (config.orderMode && orderedItemId == null) {
                            chat(mc, "§6[HugoAutoSell] §eOrder-Modus: Kiste war leer, kein Item zum Bestellen.");
                            finishCycle();
                            break;
                        }
                        String cmd = config.orderMode
                                ? "order " + orderedItemId
                                : (config.sellCommand.startsWith("/") ? config.sellCommand.substring(1) : config.sellCommand);
                        mc.field_1724.field_3944.method_45730(cmd);
                        chat(mc, "§6[HugoAutoSell] §7Sende §e/" + cmd);
                    }
                    state = config.orderMode ? State.WAITING_FOR_ORDER_SCREEN : State.WAITING_FOR_SELL_SCREEN;
                    stateTicks = 0;
                    break;

                case WAITING_FOR_ORDER_SCREEN:
                    if (mc.field_1755 instanceof class_465<?> orderScreen && stateTicks >= 8) {
                        class_1703 orderHandler = orderScreen.method_17577();
                        // HugoSMP sortiert die Ergebnisse absteigend nach Preis: Slot 0 ist das beste Angebot.
                        if (getTopContainerSlotCount(orderHandler) > 0 && orderHandler.method_7611(0).method_7681()) {
                            chat(mc, "§6[HugoAutoSell] §7Wähle beste Order (erster Slot)...");
                            mc.field_1761.method_2906(orderHandler.field_7763, 0, 0, class_1713.field_7790, mc.field_1724);
                            state = State.WAITING_FOR_ORDER_DELIVERY_SCREEN;
                            stateTicks = 0;
                        } else {
                            chat(mc, "§6[HugoAutoSell] §cKeine offene Order für " + orderedItemId + " gefunden.");
                            finishCycle();
                        }
                    } else if (stateTicks > 80) {
                        chat(mc, "§6[HugoAutoSell] §cOrder-Menü wurde nicht geöffnet, überspringe...");
                        finishCycle();
                    }
                    break;

                case WAITING_FOR_ORDER_DELIVERY_SCREEN:
                    if (mc.field_1755 instanceof class_465<?> deliveryScreen && stateTicks >= 8) {
                        class_1703 deliveryHandler = deliveryScreen.method_17577();
                        int deliverSlot = findSlotByName(deliveryHandler, "ganzes inventar liefern");
                        if (deliverSlot >= 0) {
                            chat(mc, "§6[HugoAutoSell] §7Liefere gesamtes Inventar...");
                            mc.field_1761.method_2906(deliveryHandler.field_7763, deliverSlot, 0, class_1713.field_7790, mc.field_1724);
                            state = State.WAITING_FOR_ORDER_CONFIRMATION;
                            stateTicks = 0;
                        } else if (stateTicks > 80) {
                            chat(mc, "§6[HugoAutoSell] §cSchaltfläche 'Ganzes Inventar liefern' nicht gefunden.");
                            finishCycle();
                        }
                    } else if (stateTicks > 80) {
                        chat(mc, "§6[HugoAutoSell] §cOrder-Liefermenü wurde nicht geöffnet, überspringe...");
                        finishCycle();
                    }
                    break;

                case WAITING_FOR_ORDER_CONFIRMATION:
                    if (mc.field_1755 instanceof class_465<?> confirmationScreen && stateTicks >= 8) {
                        class_1703 confirmationHandler = confirmationScreen.method_17577();
                        int confirmSlot = findSlotByName(confirmationHandler, "bestätigen");
                        if (confirmSlot >= 0) {
                            chat(mc, "§6[HugoAutoSell] §7Bestätige Order...");
                            mc.field_1761.method_2906(confirmationHandler.field_7763, confirmSlot, 0, class_1713.field_7790, mc.field_1724);
                            state = State.FINISHING_CYCLE;
                            stateTicks = 0;
                        } else if (stateTicks > 80) {
                            chat(mc, "§6[HugoAutoSell] §cBestätigungs-Schaltfläche nicht gefunden.");
                            finishCycle();
                        }
                    } else if (stateTicks > 80) {
                        chat(mc, "§6[HugoAutoSell] §cOrder-Bestätigung wurde nicht geöffnet, überspringe...");
                        finishCycle();
                    }
                    break;

                case WAITING_FOR_SELL_SCREEN:
                    if (mc.field_1755 instanceof class_465<?>) {
                        state = State.FILLING_SELL_GUI;
                        stateTicks = 0;
                        fillPlayerSlotIndex = 0;
                        fillPass = 0;
                    } else if (stateTicks > 80) {
                        chat(mc, "§6[HugoAutoSell] §cSell-GUI wurde nicht geöffnet, überspringe...");
                        finishCycle();
                    }
                    break;

                case FILLING_SELL_GUI:
                    if (!(mc.field_1755 instanceof class_465<?> sellScreen)) {
                        finishCycle();
                        return;
                    }

                    if (stateTicks < 6) {
                        return;
                    }

                    class_1703 sellHandler = sellScreen.method_17577();
                    int totalSlots = sellHandler.field_7761.size();
                    int playerStart = Math.max(0, totalSlots - 36);
                    int totalPlayerSlots = totalSlots - playerStart;

                    if (stateTicks % Math.max(1, config.clickDelayTicks) == 0) {
                        if (fillPlayerSlotIndex < totalPlayerSlots) {
                            int slotIndex = playerStart + fillPlayerSlotIndex;
                            class_1735 slot = sellHandler.method_7611(slotIndex);
                            if (slot != null && slot.method_7681() && !slot.method_7677().method_7960()) {
                                mc.field_1761.method_2906(sellHandler.field_7763, slotIndex, 0, class_1713.field_7794, mc.field_1724);
                            }
                            fillPlayerSlotIndex++;
                        } else {
                            fillPass++;
                            fillPlayerSlotIndex = 0;
                            if (fillPass >= 2) {
                                state = State.CONFIRMING_SELL;
                                stateTicks = 0;
                            }
                        }
                    }
                    break;

                case CONFIRMING_SELL:
                    if (!(mc.field_1755 instanceof class_465<?> confirmScreen)) {
                        finishCycle();
                        return;
                    }

                    if (stateTicks >= 8) {
                        class_1703 confirmHandler = confirmScreen.method_17577();
                        int confirmTopSlots = getTopContainerSlotCount(confirmHandler);

                        int confirmSlot = findConfirmButtonSlot(confirmHandler, confirmTopSlots);
                        if (confirmSlot >= 0) {
                            chat(mc, "§6[HugoAutoSell] §7Bestätige Verkauf (Slot §e" + confirmSlot + "§7)...");
                            mc.field_1761.method_2906(confirmHandler.field_7763, confirmSlot, 0, class_1713.field_7790, mc.field_1724);
                        } else {
                            chat(mc, "§6[HugoAutoSell] §cKein Bestätigungs-Button gefunden!");
                        }

                        state = State.FINISHING_CYCLE;
                        stateTicks = 0;
                    }
                    break;

                case FINISHING_CYCLE:
                    if (stateTicks >= 8) {
                        if (mc.field_1724 != null) {
                            mc.field_1724.method_7346();
                        }
                        mc.method_1507(null);
                        finishCycle();
                    }
                    break;

                case IDLE:
                default:
                    break;
            }
        }
    }

    private void finishCycle() {
        this.state = State.WAITING_TIMER;
        this.stateTicks = 0;
        this.remainingCooldownTicks = config.intervalSeconds * 20;
        this.fillPlayerSlotIndex = 0;
        this.fillPass = 0;

        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null) {
            int minutes = config.intervalSeconds / 60;
            int seconds = config.intervalSeconds % 60;
            String timeStr = (minutes > 0) ? (minutes + " Min " + (seconds > 0 ? seconds + "s" : "")) : (seconds + "s");
            String action = config.orderMode ? "Bestellung" : "Verkauf";
            chat(mc, "§6[HugoAutoSell] §a✔ " + action + " abgeschlossen! Nächster Durchlauf in §e" + timeStr + "§7.");
        }
    }

    private int getTopContainerSlotCount(class_1703 handler) {
        if (handler instanceof class_1707 genericHandler) {
            return genericHandler.method_17388() * 9;
        }
        int total = handler.field_7761.size();
        if (total >= 90) return 54;
        if (total >= 63) return 27;
        return Math.max(0, total - 36);
    }

    private int findConfirmButtonSlot(class_1703 handler, int topSlots) {
        for (int i = 0; i < topSlots; i++) {
            class_1735 slot = handler.method_7611(i);
            if (slot != null && slot.method_7681()) {
                net.minecraft.class_1799 stack = slot.method_7677();
                String name = stack.method_7964().getString().toLowerCase();
                String itemId = stack.method_7909().toString().toLowerCase();
                if (name.contains("bestätig") || name.contains("verkauf") || name.contains("confirm")
                        || name.contains("sell") || name.contains("ja") || name.contains("accept")
                        || itemId.contains("lime") || itemId.contains("green")
                        || itemId.contains("emerald") || itemId.contains("check")) {
                    return i;
                }
            }
        }

        int total = handler.field_7761.size();
        if (total > 53) return 53;
        if (topSlots > 0) return topSlots - 1;
        return 0;
    }

    /** Finds a HugoSMP menu button by its visible label, only in the menu area. */
    private int findSlotByName(class_1703 handler, String expectedName) {
        int topSlots = getTopContainerSlotCount(handler);
        String expected = expectedName.toLowerCase(java.util.Locale.ROOT);
        for (int i = 0; i < topSlots; i++) {
            class_1735 slot = handler.method_7611(i);
            if (slot != null && slot.method_7681()
                    && slot.method_7677().method_7964().getString().toLowerCase(java.util.Locale.ROOT).contains(expected)) {
                return i;
            }
        }
        return -1;
    }

    private void renderActionBar(class_310 mc) {
        if (state == State.WAITING_TIMER) {
            int totalSeconds = remainingCooldownTicks / 20;
            int minutes = totalSeconds / 60;
            int seconds = totalSeconds % 60;
            String timeFormatted = String.format("%02d:%02d", minutes, seconds);
            actionBar(mc, "§6[AutoSell] §aAktiv §7| Nächster Verkauf: §e" + timeFormatted);
        } else {
            String stepName = switch (state) {
                case OPENING_CHEST -> "Öffne Kiste...";
                case WAITING_FOR_CHEST_SCREEN -> "Warte auf Kiste...";
                case LOOTING_CHEST -> "Leere Kiste...";
                case CLOSING_CHEST -> "Schließe Kiste...";
                case WAITING_FOR_INVENTORY_SYNC -> "Sync Inventar...";
                case WAITING_BEFORE_COMMAND -> "Warte vor Befehl...";
                case SENDING_SELL_COMMAND -> config.orderMode ? "Sende /order..." : "Sende /" + config.sellCommand + "...";
                case WAITING_FOR_ORDER_SCREEN -> "Warte auf Order-Liste...";
                case WAITING_FOR_ORDER_DELIVERY_SCREEN -> "Wähle Inventar-Lieferung...";
                case WAITING_FOR_ORDER_CONFIRMATION -> "Bestätige Order...";
                case WAITING_FOR_SELL_SCREEN -> "Warte auf Sell-GUI...";
                case FILLING_SELL_GUI -> "Lege Items in Verkauf...";
                case CONFIRMING_SELL -> "Bestätige Verkauf (✅)...";
                case FINISHING_CYCLE -> "Fertiggestellt!";
                default -> "In Arbeit...";
            };
            actionBar(mc, "§6[AutoSell] §b" + stepName);
        }
    }

    private void actionBar(class_310 mc, String text) {
        if (mc.field_1724 != null) {
            mc.field_1724.method_7353(class_2561.method_43470(text), true);
        }
    }

    private void chat(class_310 mc, String text) {
        if (mc.field_1724 != null) {
            mc.field_1724.method_7353(class_2561.method_43470(text), false);
        }
    }

    /** Prüft ob Block an Position eine Lager-Kiste ist (Truhe, Fass, Shulker, etc.) */
    public static boolean isStorageBlock(class_310 mc, class_2338 pos) {
        if (mc.field_1687 == null) return false;
        class_2680 state = mc.field_1687.method_8320(pos);
        class_2248 block = state.method_26204();
        String id = class_7923.field_41175.method_10221(block).toString();
        return id.contains("chest")
            || id.contains("barrel")
            || id.contains("shulker_box")
            || id.contains("hopper")
            || id.contains("dispenser")
            || id.contains("dropper")
            || id.contains("crate")
            || id.contains("chiseled_bookshelf");
    }
}
