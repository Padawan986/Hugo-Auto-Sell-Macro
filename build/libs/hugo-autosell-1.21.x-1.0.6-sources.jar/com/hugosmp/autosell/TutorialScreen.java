package com.hugosmp.autosell;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class TutorialScreen extends class_437 {

    private static final int BG_COLOR = 0xDD111111;
    private static final int ACCENT = 0xFFFFAA00;
    private static final int WHITE = 0xFFFFFFFF;
    private static final int GRAY = 0xFFAAAAAA;
    private static final int GREEN = 0xFF55FF55;

    private final class_437 parent;

    public TutorialScreen(class_437 parent) {
        super(class_2561.method_43470("Hugo SMP Auto-Sell - Tutorial"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int buttonWidth = 200;
        int buttonX = (this.field_22789 - buttonWidth) / 2;

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Verstanden!"), button -> {
            AutoSellConfig cfg = AutoSellManager.getInstance().getConfig();
            cfg.hasSeenTutorial = true;
            cfg.save();
            class_310.method_1551().method_1507(parent);
        }).method_46434(buttonX, this.field_22790 - 50, buttonWidth, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        int centerX = this.field_22789 / 2;
        int startY = 40;
        int lineHeight = 18;
        int y = startY;
        class_310 mc = class_310.method_1551();

        // Titel
        context.method_27534(mc.field_1772, class_2561.method_43470("Hugo SMP Auto-Sell").method_27661().method_27694(s -> s.method_36139(ACCENT).method_10982(true)), centerX, y, ACCENT);
        y += lineHeight + 4;
        context.method_27534(mc.field_1772, class_2561.method_43470("Erste Schritte").method_27661().method_27694(s -> s.method_36139(WHITE)), centerX, y, WHITE);
        y += lineHeight + 12;

        // Trennlinie
        int boxW = 320;
        context.method_25294(centerX - boxW / 2, y, centerX + boxW / 2, y + 1, ACCENT);
        y += 12;

        // Schritt 1
        context.method_27534(mc.field_1772, class_2561.method_43470("Schritt 1: Makro starten").method_27661().method_27694(s -> s.method_36139(GREEN)), centerX, y, GREEN);
        y += lineHeight;
        context.method_27534(mc.field_1772, class_2561.method_43470("Schaue eine Kiste an und druecke [K]").method_27661().method_27694(s -> s.method_36139(GRAY)), centerX, y, GRAY);
        y += lineHeight - 4;
        context.method_27534(mc.field_1772, class_2561.method_43470("Die Kiste wird als Ziel gespeichert & das Makro startet.").method_27661().method_27694(s -> s.method_36139(GRAY)), centerX, y, GRAY);
        y += lineHeight + 8;

        // Schritt 2
        context.method_27534(mc.field_1772, class_2561.method_43470("Schritt 2: Makro stoppen").method_27661().method_27694(s -> s.method_36139(GREEN)), centerX, y, GREEN);
        y += lineHeight;
        context.method_27534(mc.field_1772, class_2561.method_43470("Druecke einfach nochmal [K] um es zu deaktivieren.").method_27661().method_27694(s -> s.method_36139(GRAY)), centerX, y, GRAY);
        y += lineHeight + 8;

        // Schritt 3
        context.method_27534(mc.field_1772, class_2561.method_43470("Schritt 3: Befehle").method_27661().method_27694(s -> s.method_36139(GREEN)), centerX, y, GREEN);
        y += lineHeight;
        String[] commands = {
                "/autosell status     - Zeigt aktuellen Status",
                "/autosell interval <s> - Timer aendern (5-3600s)",
                "/autosell command <c> - Verkaufsbefehl aendern",
                "/autosell toggle      - Makro an/aus",
        };
        for (String cmd : commands) {
            context.method_27534(mc.field_1772, class_2561.method_43470(cmd).method_27661().method_27694(s -> s.method_36139(GRAY)), centerX, y, GRAY);
            y += lineHeight - 2;
        }
        y += 8;

        // Schritt 4
        context.method_27534(mc.field_1772, class_2561.method_43470("Schritt 4: HUD Overlay").method_27661().method_27694(s -> s.method_36139(GREEN)), centerX, y, GREEN);
        y += lineHeight;
        context.method_27534(mc.field_1772, class_2561.method_43470("Ueber der Hotbar siehst du Status & Timer.").method_27661().method_27694(s -> s.method_36139(GRAY)), centerX, y, GRAY);
        y += lineHeight - 4;
        context.method_27534(mc.field_1772, class_2561.method_43470("Orange = Timer  |  Gruen = Aktion laeuft").method_27661().method_27694(s -> s.method_36139(GRAY)), centerX, y, GRAY);

        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
