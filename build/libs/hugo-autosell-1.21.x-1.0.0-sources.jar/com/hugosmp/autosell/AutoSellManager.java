package com.hugosmp.autosell;

import net.minecraft.class_1268;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_465;

public class AutoSellManager {
    public enum State {
        IDLE,
        WAITING_TIMER,
        OPENING_CHEST,
        WAITING_FOR_CHEST_SCREEN,
        LOOTING_CHEST,
        CLOSING_CHEST,
        WAITING_FOR_INVENTORY_SYNC,
        WAITING_BEFORE_COMMAND,
        SENDING_SELL_COMMAND,
        WAITING_FOR_SELL_SCREEN,
        FILLING_SELL_GUI,
        CONFIRMING_SELL,
        FINISHING_CYCLE
    }

    private static final AutoSellManager INSTANCE = new AutoSellManager();
    public static AutoSellManager getInstance() {
        return INSTANCE;
    }

    private final AutoSellConfig config = AutoSellConfig.load();
    private boolean active = false;
    private class_2338 targetChestPos = null;

    private State state = State.IDLE;
    private int stateTicks = 0;
    private int remainingCooldownTicks = 0;
    private int currentSlotIndex = 0;
    private int fillPlayerSlotIndex = 0;
    private int fillPass = 0;

    private AutoSellManager() {}

    public AutoSellConfig getConfig() {
        return config;
    }

    public boolean isActive() {
        return active;
    }

    public class_2338 getTargetChestPos() {
        return targetChestPos;
    }

    public void toggle() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;

        if (active) {
            stop();
            mc.field_1724.method_7353(class_2561.method_43470("§6[HugoAutoSell] §c✖ Makro DEAKTIVIERT!"), false);
        } else {
            class_239 hit = mc.field_1765;
            if (hit != null && hit.method_17783() == class_239.class_240.field_1332) {
                class_3965 blockHit = (class_3965) hit;
                this.targetChestPos = blockHit.method_17777();
                start();
                mc.field_1724.method_7353(class_2561.method_43470("§6[HugoAutoSell] §a✔ Makro AKTIVIERT!"), false);
                mc.field_1724.method_7353(class_2561.method_43470("§6[HugoAutoSell] §7Zielkiste gespeichert bei: §e" 
                        + targetChestPos.method_10263() + ", " + targetChestPos.method_10264() + ", " + targetChestPos.method_10260()), false);
                mc.field_1724.method_7353(class_2561.method_43470("§6[HugoAutoSell] §7Intervall: §e" + config.intervalSeconds 
                        + "s (" + (config.intervalSeconds / 60) + " Min) §7| Starte ersten Verkauf..."), false);
            } else if (this.targetChestPos != null) {
                start();
                mc.field_1724.method_7353(class_2561.method_43470("§6[HugoAutoSell] §a✔ Makro AKTIVIERT! (Vorherige Kiste bei: §e" 
                        + targetChestPos.method_10263() + ", " + targetChestPos.method_10264() + ", " + targetChestPos.method_10260() + "§a)"), false);
                mc.field_1724.method_7353(class_2561.method_43470("§6[HugoAutoSell] §7Intervall: §e" + config.intervalSeconds 
                        + "s (" + (config.intervalSeconds / 60) + " Min) §7| Starte ersten Verkauf..."), false);
            } else {
                mc.field_1724.method_7353(class_2561.method_43470("§6[HugoAutoSell] §cBitte schaue eine Kiste an und drücke die Taste erneut!"), false);
            }
        }
    }

    public void start() {
        this.active = true;
        this.remainingCooldownTicks = 0;
        this.state = State.OPENING_CHEST;
        this.stateTicks = 0;
        this.fillPlayerSlotIndex = 0;
        this.fillPass = 0;
    }

    public void stop() {
        this.active = false;
        this.state = State.IDLE;
        this.stateTicks = 0;
        this.remainingCooldownTicks = 0;
        this.fillPlayerSlotIndex = 0;
        this.fillPass = 0;
    }

    public void onTick(class_310 mc) {
        if (!active || mc.field_1724 == null || mc.field_1687 == null) {
            return;
        }

        renderActionBar(mc);

        stateTicks++;

        switch (state) {
            case WAITING_TIMER:
                if (remainingCooldownTicks > 0) {
                    if (remainingCooldownTicks == 1200) {
                        mc.field_1724.method_7353(class_2561.method_43470("§6[HugoAutoSell] §e⏳ Nächster Verkauf in 1 Minute (60 Sekunden)..."), false);
                    } else if (remainingCooldownTicks == 200) {
                        mc.field_1724.method_7353(class_2561.method_43470("§6[HugoAutoSell] §e⏳ Nächster Verkauf in 10 Sekunden..."), false);
                    }
                    remainingCooldownTicks--;
                } else {
                    mc.field_1724.method_7353(class_2561.method_43470("§6[HugoAutoSell] §b🔄 Timer abgelaufen: Öffne Kiste und verkaufe Items..."), false);
                    state = State.OPENING_CHEST;
                    stateTicks = 0;
                }
                break;

            case OPENING_CHEST:
                if (targetChestPos == null) {
                    stop();
                    mc.field_1724.method_7353(class_2561.method_43470("§c[AutoSell] Keine Kiste ausgewählt!"), false);
                    return;
                }

                double distSq = mc.field_1724.method_24515().method_10262(targetChestPos);
                if (distSq > 36.0) {
                    mc.field_1724.method_7353(class_2561.method_43470("§c[AutoSell] Kiste ist zu weit entfernt!"), false);
                    stop();
                    return;
                }

                class_3965 hitResult = new class_3965(
                        class_243.method_24953(targetChestPos),
                        class_2350.field_11036,
                        targetChestPos,
                        false
                );
                mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hitResult);
                mc.field_1724.method_6104(class_1268.field_5808);

                state = State.WAITING_FOR_CHEST_SCREEN;
                stateTicks = 0;
                break;

            case WAITING_FOR_CHEST_SCREEN:
                if (mc.field_1755 instanceof class_465<?>) {
                    state = State.LOOTING_CHEST;
                    stateTicks = 0;
                    currentSlotIndex = 0;
                } else if (stateTicks > 40) {
                    state = State.OPENING_CHEST;
                    stateTicks = 0;
                }
                break;

            case LOOTING_CHEST:
                if (!(mc.field_1755 instanceof class_465<?> handledScreen)) {
                    state = State.OPENING_CHEST;
                    stateTicks = 0;
                    return;
                }

                class_1703 handler = handledScreen.method_17577();
                int containerSlots = getTopContainerSlotCount(handler);

                if (stateTicks % Math.max(1, config.clickDelayTicks) == 0) {
                    boolean itemMoved = false;
                    while (currentSlotIndex < containerSlots) {
                        class_1735 slot = handler.method_7611(currentSlotIndex);
                        if (slot != null && slot.method_7681() && !slot.method_7677().method_7960()) {
                            mc.field_1761.method_2906(handler.field_7763, currentSlotIndex, 0, class_1713.field_7794, mc.field_1724);
                            currentSlotIndex++;
                            itemMoved = true;
                            break;
                        }
                        currentSlotIndex++;
                    }

                    if (!itemMoved && currentSlotIndex >= containerSlots) {
                        state = State.CLOSING_CHEST;
                        stateTicks = 0;
                    }
                }
                break;

            case CLOSING_CHEST:
                if (mc.field_1724 != null) {
                    mc.field_1724.method_7346();
                }
                mc.method_1507(null);
                state = State.WAITING_FOR_INVENTORY_SYNC;
                stateTicks = 0;
                break;

            case WAITING_FOR_INVENTORY_SYNC:
                if (stateTicks >= 10) {
                    state = State.WAITING_BEFORE_COMMAND;
                    stateTicks = 0;
                }
                break;

            case WAITING_BEFORE_COMMAND:
                if (stateTicks >= 6) {
                    state = State.SENDING_SELL_COMMAND;
                    stateTicks = 0;
                }
                break;

            case SENDING_SELL_COMMAND:
                if (mc.field_1724 != null && mc.field_1724.field_3944 != null) {
                    String cmd = config.sellCommand.startsWith("/") ? config.sellCommand.substring(1) : config.sellCommand;
                    mc.field_1724.field_3944.method_45730(cmd);
                }
                state = State.WAITING_FOR_SELL_SCREEN;
                stateTicks = 0;
                break;

            case WAITING_FOR_SELL_SCREEN:
                if (mc.field_1755 instanceof class_465<?>) {
                    state = State.FILLING_SELL_GUI;
                    stateTicks = 0;
                    fillPlayerSlotIndex = 0;
                    fillPass = 0;
                } else if (stateTicks > 80) {
                    mc.field_1724.method_7353(class_2561.method_43470("§6[HugoAutoSell] §cSell-GUI wurde nicht geöffnet, überspringe..."), false);
                    finishCycle();
                }
                break;

            case FILLING_SELL_GUI:
                if (!(mc.field_1755 instanceof class_465<?> sellScreen)) {
                    finishCycle();
                    return;
                }

                if (stateTicks < 6) {
                    return;
                }

                class_1703 sellHandler = sellScreen.method_17577();
                int totalSlots = sellHandler.field_7761.size();
                int playerStart = Math.max(0, totalSlots - 36);
                int totalPlayerSlots = totalSlots - playerStart;

                if (stateTicks % Math.max(1, config.clickDelayTicks) == 0) {
                    if (fillPlayerSlotIndex < totalPlayerSlots) {
                        int slotIndex = playerStart + fillPlayerSlotIndex;
                        class_1735 slot = sellHandler.method_7611(slotIndex);
                        if (slot != null && slot.method_7681() && !slot.method_7677().method_7960()) {
                            mc.field_1761.method_2906(sellHandler.field_7763, slotIndex, 0, class_1713.field_7794, mc.field_1724);
                        }
                        fillPlayerSlotIndex++;
                    } else {
                        fillPass++;
                        fillPlayerSlotIndex = 0;
                        if (fillPass >= 2) {
                            state = State.CONFIRMING_SELL;
                            stateTicks = 0;
                        }
                    }
                }
                break;

            case CONFIRMING_SELL:
                if (!(mc.field_1755 instanceof class_465<?> confirmScreen)) {
                    finishCycle();
                    return;
                }

                if (stateTicks >= 8) {
                    class_1703 confirmHandler = confirmScreen.method_17577();
                    int confirmTopSlots = getTopContainerSlotCount(confirmHandler);

                    int confirmSlot = findConfirmButtonSlot(confirmHandler, confirmTopSlots);
                    if (confirmSlot >= 0) {
                        mc.field_1724.method_7353(class_2561.method_43470("§6[HugoAutoSell] §7Bestätige Verkauf (Slot §e" + confirmSlot + "§7)..."), false);
                        mc.field_1761.method_2906(confirmHandler.field_7763, confirmSlot, 0, class_1713.field_7790, mc.field_1724);
                    } else {
                        mc.field_1724.method_7353(class_2561.method_43470("§6[HugoAutoSell] §cKein Bestätigungs-Button gefunden!"), false);
                    }

                    state = State.FINISHING_CYCLE;
                    stateTicks = 0;
                }
                break;

            case FINISHING_CYCLE:
                if (stateTicks >= 8) {
                    if (mc.field_1724 != null) {
                        mc.field_1724.method_7346();
                    }
                    mc.method_1507(null);
                    finishCycle();
                }
                break;

            case IDLE:
            default:
                break;
        }
    }

    private void finishCycle() {
        this.state = State.WAITING_TIMER;
        this.stateTicks = 0;
        this.remainingCooldownTicks = config.intervalSeconds * 20;
        this.fillPlayerSlotIndex = 0;
        this.fillPass = 0;

        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null) {
            int minutes = config.intervalSeconds / 60;
            int seconds = config.intervalSeconds % 60;
            String timeStr = (minutes > 0) ? (minutes + " Min " + (seconds > 0 ? seconds + "s" : "")) : (seconds + "s");
            mc.field_1724.method_7353(class_2561.method_43470("§6[HugoAutoSell] §a✔ Verkauf abgeschlossen! Nächster Durchlauf in §e" + timeStr + "§7."), false);
        }
    }

    private int getTopContainerSlotCount(class_1703 handler) {
        if (handler instanceof class_1707 genericHandler) {
            return genericHandler.method_17388() * 9;
        }
        int total = handler.field_7761.size();
        if (total >= 90) return 54;
        if (total >= 63) return 27;
        return Math.max(0, total - 36);
    }

    private int findConfirmButtonSlot(class_1703 handler, int topSlots) {
        for (int i = 0; i < topSlots; i++) {
            class_1735 slot = handler.method_7611(i);
            if (slot != null && slot.method_7681()) {
                class_1799 stack = slot.method_7677();
                String name = stack.method_7964().getString().toLowerCase();
                String itemId = stack.method_7909().toString().toLowerCase();
                if (name.contains("bestätig") || name.contains("verkauf") || name.contains("confirm")
                        || name.contains("sell") || name.contains("ja") || name.contains("accept")
                        || itemId.contains("lime") || itemId.contains("green")
                        || itemId.contains("emerald") || itemId.contains("check")) {
                    return i;
                }
            }
        }

        int total = handler.field_7761.size();
        if (total > 53) return 53;
        if (topSlots > 0) return topSlots - 1;
        return 0;
    }

    private void renderActionBar(class_310 mc) {
        if (state == State.WAITING_TIMER) {
            int totalSeconds = remainingCooldownTicks / 20;
            int minutes = totalSeconds / 60;
            int seconds = totalSeconds % 60;
            String timeFormatted = String.format("%02d:%02d", minutes, seconds);
            mc.field_1724.method_7353(class_2561.method_43470("§6[AutoSell] §aAktiv §7| Nächster Verkauf in: §e" + timeFormatted), true);
        } else {
            String stepName = switch (state) {
                case OPENING_CHEST -> "Öffne Kiste...";
                case WAITING_FOR_CHEST_SCREEN -> "Warte auf Kiste...";
                case LOOTING_CHEST -> "Leere Kiste...";
                case CLOSING_CHEST -> "Schließe Kiste...";
                case WAITING_FOR_INVENTORY_SYNC -> "Warte auf Inventar-Sync...";
                case WAITING_BEFORE_COMMAND -> "Warte vor Befehl...";
                case SENDING_SELL_COMMAND -> "Sende /sell...";
                case WAITING_FOR_SELL_SCREEN -> "Warte auf Sell-GUI...";
                case FILLING_SELL_GUI -> "Lege Items in Verkauf...";
                case CONFIRMING_SELL -> "Bestätige Verkauf (✅)...";
                case FINISHING_CYCLE -> "Fertiggestellt!";
                default -> "In Arbeit...";
            };
            mc.field_1724.method_7353(class_2561.method_43470("§6[AutoSell] §b" + stepName), true);
        }
    }
}
