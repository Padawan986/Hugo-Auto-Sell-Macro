package com.hugosmp.autosell;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class UpdateStatusScreen extends class_437 {
    private final String message;
    private final boolean canRestart;

    public UpdateStatusScreen(String message, boolean canRestart) {
        super(class_2561.method_43470("Hugo Auto-Sell Update"));
        this.message = message;
        this.canRestart = canRestart;
    }

    @Override
    protected void method_25426() {
        if (canRestart) {
            this.method_37063(class_4185.method_46430(class_2561.method_43470("Minecraft beenden"), button -> class_310.method_1551().method_1592())
                    .method_46434(this.field_22789 / 2 - 100, this.field_22790 / 2 + 20, 200, 20).method_46431());
        } else {
            this.method_37063(class_4185.method_46430(class_2561.method_43470("Schließen"), button -> class_310.method_1551().method_1507(null))
                    .method_46434(this.field_22789 / 2 - 100, this.field_22790 / 2 + 20, 200, 20).method_46431());
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_27534(this.field_22793, class_2561.method_43470("Hugo SMP Auto-Sell Update"), this.field_22789 / 2, this.field_22790 / 2 - 25, 0xFFFFAA00);
        context.method_27534(this.field_22793, class_2561.method_43470(message), this.field_22789 / 2, this.field_22790 / 2, 0xFFFFFFFF);
        super.method_25394(context, mouseX, mouseY, delta);
    }
}
