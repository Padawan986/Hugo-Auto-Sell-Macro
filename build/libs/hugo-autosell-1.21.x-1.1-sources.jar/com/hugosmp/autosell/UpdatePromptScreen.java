package com.hugosmp.autosell;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/** Explicit in-game consent dialog for an available update. */
public class UpdatePromptScreen extends class_437 {
    private final HugoAutoSellUpdater.Update update;

    public UpdatePromptScreen(HugoAutoSellUpdater.Update update) {
        super(class_2561.method_43470("Hugo Auto-Sell Update"));
        this.update = update;
    }

    @Override
    protected void method_25426() {
        int x = this.field_22789 / 2 - 105;
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Ja, herunterladen"), button -> {
            class_310 client = class_310.method_1551();
            client.method_1507(new UpdateStatusScreen("Update wird heruntergeladen...", false));
            HugoAutoSellUpdater.downloadAndInstall(update, error -> client.execute(() ->
                    client.method_1507(new UpdateStatusScreen(
                            error == null ? "Update installiert. Minecraft jetzt neu starten." : "Update fehlgeschlagen: " + error,
                            error == null
                    ))
            ));
        }).method_46434(x, this.field_22790 / 2 + 25, 100, 20).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Nein"), button -> class_310.method_1551().method_1507(null))
                .method_46434(x + 110, this.field_22790 / 2 + 25, 100, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_27534(this.field_22793, class_2561.method_43470("Hugo SMP Auto-Sell Update"), this.field_22789 / 2, this.field_22790 / 2 - 35, 0xFFFFAA00);
        context.method_27534(this.field_22793, class_2561.method_43470("Version " + update.version() + " ist verfügbar."), this.field_22789 / 2, this.field_22790 / 2 - 10, 0xFFFFFFFF);
        context.method_27534(this.field_22793, class_2561.method_43470("Jetzt herunterladen und beim Neustart verwenden?"), this.field_22789 / 2, this.field_22790 / 2 + 5, 0xFFAAAAAA);
        super.method_25394(context, mouseX, mouseY, delta);
    }
}
